package com.rahmanarif.footballclubschedule.model

data class EventsResponse(
        val events: List<Events>
)